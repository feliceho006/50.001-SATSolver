package com.example.lib;

public class MyClass {
}